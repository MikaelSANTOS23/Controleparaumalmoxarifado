
package Classes;

import Formularios.frmLogin;

/**
 *
 * @author Mikael Vitor Santos e Robson Castro
 */
public class ContrleDeAlmoxarifado {

    public static void main(String[] args) {
       frmLogin miLogin = new frmLogin();
       miLogin.setLocationRelativeTo(null);
       miLogin.setVisible(true);
        
    }
    
}
